<div class="row footer">
    <div class="col-10 offset-1">
        <div class="row">
            <div class="col-12" style="color:#FFFFFF;" align="right">
                <i class="fa fa-copyright"> 2017 PT . IDN IBE Soluside</i>
            </div>
        </div>
    </div>
</div>
