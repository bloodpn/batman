<div class="row header">
    <div class="col-10 offset-1">
        <div class="row">
            <div class="col-6">
                <img src="/images/logo_xtrans.png" width="30%">
            </div>
            <div class="col-6" align="right">
                <a href="#">HOME</a>
                  |
                <a href="#"> FAQ</a>
                  |
                <a data-toggle="collapse" href="#caritiket">CEK BOOKING</a>
                  <div id="caritiket" class="panel-collapse collapse">
                    <div class="row">
                      <div class="col-12">
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="Masukan Kode Tiket">
                          <span class="input-group-btn">
                            <a href="cektiket" class="btn btn-info">Cari</a>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
            </div>
        </div>
    </div>
</div>
