<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DatapaketController extends Controller
{
    public function index()
    {
    	return view('customer/datapaket');
    }
}
