<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Car extends Model
{
	protected $table = 'cars';
    public function Jadwal()
    {
        return $this->hasMany('App/Models/Jadwal', 'id_schedule');

    }
}
