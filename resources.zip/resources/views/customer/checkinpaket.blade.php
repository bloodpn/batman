@extends('customer.default')

@section('title','Check in Paket')

@section('content')

<div class="box box-primary box-solid direct-chat direct-chat-primary">
	<div class="box-header">
		<a href="/"><i class="fa fa-home fa-lg"></i></a> | 
		<h3 class="box-title">Check in Paket</h3>
			<div class="box-tools pull-right">
    			<button class="btn btn-box-tool" data-toggle="tooltip" title="Contacts" data-widget="chat-pane-toggle">Bantuan</button>
  			</div>
	</div>
	<br>
	<div class="box-body">
		
	</div>
</div>

@endsection