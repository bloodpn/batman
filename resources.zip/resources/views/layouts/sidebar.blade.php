  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="treeview">
          <a href="#">
            <i class="fa fa-laptop"></i>
            <span>Master Data</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
			<li><a href="mastercustomer"><i class="fa fa-circle-o text-aqua"></i> Master Customer</a></li>
      <li><a href="mastercabang"><i class="fa fa-circle-o text-aqua"></i>Master Cabang</a></li>
      <li><a href="masterjurusan"><i class="fa fa-circle-o text-aqua"></i>Master Jurusan</a></li>
      <li><a href="masterarea"><i class="fa fa-circle-o text-aqua"></i>Master Area</a></li>
			<li><a href="masterjadwal"><i class="fa fa-circle-o text-aqua"></i> Master Jadwal</a></li>
            <li><a href="masterkendaraan"><i class="fa fa-circle-o text-aqua"></i> Master Kendaraan</a></li>
			<li><a href="mastersupir"><i class="fa fa-circle-o text-aqua"></i> Master Supir</a></li>
      <li><a href="masteruser"><i class="fa fa-circle-o text-aqua"></i>Master User</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-bus"></i> <span>Travel</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="reservasi"><i class="fa fa-circle-o text-aqua"></i>Reservasi</a></li>
          </ul>
        </li>
        <li>
          <a href="pages/calendar.html">
            <i class="fa fa-truck"></i> <span>Paket</span>
             <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="paket"><i class=""></i>Pengiriman Paket</a></li>
            <li><a href="checkinpaket"><i class=""></i>Check in paket</a></li>
          </ul>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>