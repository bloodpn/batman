@extends('layouts.master')

@section('title','About')

@section('content')
<h1>ini sekilas tentang kami</h1>
<p>kami adalah ......</p>
 @endsection