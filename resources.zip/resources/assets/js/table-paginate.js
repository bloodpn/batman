<!-- Panggil Fungsi -->
    $(document).ready(function() {
	$('.table-paginate').dataTable();
 } );